-- AL AMANAH UNITY: Supabase database setup
-- Run in Supabase SQL Editor. Review with a developer before production use.
create table if not exists public.member_accounts (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique references auth.users(id) on delete cascade,
  member_id text unique not null,
  full_name text not null,
  email text,
  shares integer not null default 0 check (shares >= 0),
  monthly_contribution_omr numeric(12,3) not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  member_account_id uuid not null references public.member_accounts(id) on delete cascade,
  payment_date date,
  month_label text,
  amount_received_omr numeric(12,3) not null default 0,
  payment_status text not null default 'Pending',
  receipt_no text unique,
  created_at timestamptz not null default now()
);
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null
);
alter table public.member_accounts enable row level security;
alter table public.payments enable row level security;
alter table public.admin_users enable row level security;
create or replace function public.is_society_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.admin_users a where a.user_id=auth.uid()); $$;
create policy "member sees own profile or admin sees all"
on public.member_accounts for select to authenticated
using (auth_user_id=auth.uid() or public.is_society_admin());
create policy "admin manages member accounts"
on public.member_accounts for all to authenticated
using (public.is_society_admin()) with check (public.is_society_admin());
create policy "member sees own payments or admin sees all"
on public.payments for select to authenticated
using (exists(select 1 from public.member_accounts m where m.id=member_account_id and m.auth_user_id=auth.uid()) or public.is_society_admin());
create policy "admin manages payments"
on public.payments for all to authenticated
using (public.is_society_admin()) with check (public.is_society_admin());
create policy "admin can read admin list"
on public.admin_users for select to authenticated
using (user_id=auth.uid());
-- After creating the Admin user in Supabase Auth, add their UUID and official email:
-- insert into public.admin_users(user_id,email) values ('AUTH_USER_UUID','alamanah.unityinvestmentsocity@gmail.com');
-- Add members by creating/inviting Auth users, then insert matching member_accounts rows
-- with each user's auth_user_id. Never share passwords in spreadsheets or email.
