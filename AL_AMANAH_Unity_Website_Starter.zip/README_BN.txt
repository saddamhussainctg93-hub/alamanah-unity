AL AMANAH UNITY INVESTMENT SOCIETY — WEBSITE STARTER

আপনার জন্য Public Website + Member Login-এর প্রাথমিক source files তৈরি করা হয়েছে।

গুরুত্বপূর্ণ:
- এটি এখনো Live Website নয়।
- alamanahunity.org এখনো কেনা/রেজিস্টার করা হয়নি।
- Real Member Login চালু করতে Supabase backend project, database setup, member account linking, hosting এবং domain DNS configuration লাগবে।
- কোনো বাস্তব password এই package-এ রাখা হয়নি।
- সদস্যদের password email-এ পাঠাবেন না। প্রত্যেককে secure invite/password setup link পাঠানো উচিত।
- Admin service_role key কখনো index.html-এ বসাবেন না।

ফাইল:
1. index.html — Public homepage ও login interface.
2. database_setup.sql — Member/payment tables এবং Row Level Security policies.
3. members_import_template.csv — সদস্যদের data import template.

পরবর্তী কাজ:
1. Supabase-এ project তৈরি করুন।
2. SQL Editor-এ database_setup.sql চালান।
3. Auth-এ Admin account এবং member accounts তৈরি/Invite করুন।
4. প্রতিটি Auth user UUID-কে সঠিক Member ID-র সঙ্গে যুক্ত করুন।
5. Supabase Project URL ও anon key index.html-এ বসান।
6. Hosting provider-এ site publish করুন।
7. alamanahunity.org domain কিনে hosting-এর DNS records যুক্ত করুন।
8. বাস্তব ব্যবহারের আগে security review, backup এবং member consent সম্পন্ন করুন।

প্রাথমিক template-এ কোনো সদস্যের ব্যক্তিগত তথ্য বা password hard-code করা হয়নি।
